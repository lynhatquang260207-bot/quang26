def findMin(arr):
    if len(arr) == 0:
        return None

    min_number = arr[0]
    for i in range(1, len(arr)):
        if arr[i] < min_number:
            min_number = arr[i]
    return min_number


print(findMin([5, 2, 8, 1, 4]))  # 1
