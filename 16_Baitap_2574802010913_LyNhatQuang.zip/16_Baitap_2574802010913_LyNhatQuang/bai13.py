def calculateGrade(scores):
    if len(scores) == 0:
        return "F"

    total = 0
    for score in scores:
        total += score
    average = total / len(scores)

    if average >= 90:
        return "A"
    elif average >= 80:
        return "B"
    elif average >= 70:
        return "C"
    elif average >= 60:
        return "D"
    else:
        return "F"


print(calculateGrade([90, 95, 85]))  # A
print(calculateGrade([80, 85, 82]))  # B
