def calculateAverage(arr):
    if len(arr) == 0:
        return 0

    total = 0
    for number in arr:
        total += number
    return total / len(arr)


print(calculateAverage([10, 20, 30, 40, 50]))  # 30.0
