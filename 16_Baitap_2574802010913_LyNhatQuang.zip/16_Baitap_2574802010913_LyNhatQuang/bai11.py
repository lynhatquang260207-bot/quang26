def filterEvensAndSum(arr):
    total = 0
    for number in arr:
        if number % 2 == 0:
            total += number
    return total


print(filterEvensAndSum([1, 2, 3, 4, 5, 6]))  # 12
print(filterEvensAndSum([12, 14, 15, 19, 20, 100]))  # 146
