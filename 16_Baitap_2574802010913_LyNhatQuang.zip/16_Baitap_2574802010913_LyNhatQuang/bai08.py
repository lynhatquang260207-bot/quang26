def countGreaterThan(arr, value):
    count = 0
    for number in arr:
        if number > value:
            count += 1
    return count


print(countGreaterThan([1, 5, 7, 2, 3], 3))  # 2
print(countGreaterThan([2, 3, 1, -6, 8], 5)) # 1
print(countGreaterThan([], 5))                # 0
