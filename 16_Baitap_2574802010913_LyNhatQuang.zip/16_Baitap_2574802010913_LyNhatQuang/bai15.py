def removeDuplicates(arr):
    result = []
    for number in arr:
        if number not in result:
            result.append(number)
    return result


print(removeDuplicates([1, 2, 2, 3, 4, 4, 5]))  # [1, 2, 3, 4, 5]
