def findLongestWord(words):
    if len(words) == 0:
        return None

    longest = words[0]
    for word in words[1:]:
        if len(word) > len(longest):
            longest = word
    return longest


print(findLongestWord(["apple", "banana", "cherry", "date"]))  # banana
print(findLongestWord(["hello", "world", "this", "is", "great"]))  # hello
