def isAscending(arr):
    # Mang rong hoac chi co mot phan tu khong duoc xem la tang dan.
    if len(arr) < 2:
        return False

    for i in range(len(arr) - 1):
        if arr[i] >= arr[i + 1]:
            return False
    return True


print(isAscending([1, 2, 3, 5]))  # True
