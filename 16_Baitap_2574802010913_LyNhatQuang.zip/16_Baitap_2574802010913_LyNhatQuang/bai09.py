def alternateSum(arr):
    total = 0
    for i in range(len(arr)):
        if i % 2 == 0:
            total += arr[i]
        else:
            total -= arr[i]
    return total


print(alternateSum([10, 5, 6, 3]))  # 8
print(alternateSum([1, 2, 3, 4, 5]))  # 3
