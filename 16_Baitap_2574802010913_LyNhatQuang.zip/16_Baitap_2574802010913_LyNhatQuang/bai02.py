def sumOddNumbers(arr):
    total = 0
    for number in arr:
        if number % 2 != 0:
            total += number
    return total


print(sumOddNumbers([1, 2, 3, 4, 5]))  # 9
