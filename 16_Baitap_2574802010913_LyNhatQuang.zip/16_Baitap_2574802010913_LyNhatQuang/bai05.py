def sumArray(arr):
    total = 0
    for number in arr:
        total += number
    return total


print(sumArray([1, 2, 3, 4, 5]))  # 15
