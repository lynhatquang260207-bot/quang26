def countPositiveNumbers(arr):
    count = 0
    for number in arr:
        if number > 0:
            count += 1
    return count


print(countPositiveNumbers([-1, 2, 3, -4, 5]))  # 3
