def sumOfSquares(arr):
    total = 0
    for number in arr:
        total += number * number
    return total


print(sumOfSquares([1, 2, 3]))  # 14
print(sumOfSquares([4, 5, 6]))  # 77
