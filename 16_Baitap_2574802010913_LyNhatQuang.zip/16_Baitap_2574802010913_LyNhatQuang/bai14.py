def findMissingNumber(arr, n):
    expected_total = n * (n + 1) // 2
    actual_total = 0

    for number in arr:
        actual_total += number

    return expected_total - actual_total


print(findMissingNumber([1, 2, 4, 5, 6], 6))  # 3
print(findMissingNumber([3, 7, 1, 2, 8, 4, 5], 8))  # 6
print(findMissingNumber([1, 2, 3, 4], 4))  # 0
