def findMax(arr):
    if len(arr) == 0:
        return None

    max_number = arr[0]
    for i in range(1, len(arr)):
        if arr[i] > max_number:
            max_number = arr[i]
    return max_number


print(findMax([1, 3, 5, 7, 9]))       # 9
print(findMax([10, 20, 30, 40, 50])) # 50
print(findMax([-5, -2, -1, -3]))     # -1
